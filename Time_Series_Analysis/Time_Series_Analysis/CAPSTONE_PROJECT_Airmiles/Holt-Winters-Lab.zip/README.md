# Welcome to Udemy Jupyter Labs!

In order to access the jupyterlab server, please click the "Jupyterlab" button on the bottom status bar. Login to Jupyterlab will require a token. Open the "output" pane and look for a url like `http://127.0.0.1:8080/lab?token=<token>` and use the token value from the url.
